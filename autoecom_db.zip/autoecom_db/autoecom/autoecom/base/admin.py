from django.contrib import admin

# Register your models here.
from .models import *

admin.site.register(User)
admin.site.register(Product)
admin.site.register(Customer)
admin.site.register(shipping_address)
# admin.site.register(Order_status)
admin.site.register(Order)
admin.site.register(Order_item)
# admin.site.register(Shipment)
