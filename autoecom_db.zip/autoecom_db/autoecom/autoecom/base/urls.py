from django.urls import path
from . import views

urlpatterns = [

    path('',views.home, name="home"),
    # path('the_project_base/',views.nav, name="nav"),
    path('product/',views.product, name="product"),
    path('logout/', views.logoutUser, name="logout"),

    path('cart/', views.cart, name="cart"),
    path('checkout/', views.checkout, name="checkout"),
    path('update_item/', views.updateItem, name="update_item"),

    path('userdash/',views.user_dash, name="user_profile"),
    path('update_acc/',views.update_acc, name="update_acc"),


    path('productlist/', views.productlist, name="productlist"),
    path('register/', views.register, name="register"),
    path('login/', views.loginr, name='loginr'),


    path('a/', views.a, name='a'), 

]