from django.db import models
from django.contrib.auth.models import AbstractUser
from django.db.models.fields import CharField
from .manager import UserManager


# Create your models here.


class User(AbstractUser):
    username=None
    email=models.EmailField(unique=True, null=False)
    phone_no=models.CharField(max_length=11, null=True)
    created_at=models.DateTimeField(auto_now_add=True)
    USERNAME_FIELD = 'email'
    objects=UserManager()
    REQUIRED_FIELDS=[]



class Product(models.Model):
    name=models.CharField(max_length=200, null=True)
    description=models.CharField(max_length=20)
    detail=models.CharField(max_length=20)
    price=models.FloatField()

    def __str__(self):
        return self.name



class Customer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True, blank=True)
    first_name=models.CharField(max_length=20, null=True)
    last_name=models.CharField(max_length=20, null=True)
    created_at=models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return str(self.id)




# class Order_status(models.Model):
#      status=models.BooleanField(default=False, null=True , blank=False)



class Order(models.Model):
    Customer=models.ForeignKey(Customer, on_delete=models.SET_NULL, blank=True, null=True)
    status=models.BooleanField(default=False, null=True , blank=False)
    price=models.FloatField(null=True)

    def __str__(self):
        return str(self.id)

    @property
    def get_cart_total(self):
        orderitems = self.order_item_set.all()
        total = sum([item.get_total for item in orderitems])
        return total
    
    @property
    def get_cart_items(self):
        orderitems = self.order_item_set.all()
        total = sum([item.quantity for item in orderitems])
        return total


class shipping_address(models.Model):
    Customer=models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True)
    Order=models.ForeignKey(Order, on_delete=models.SET_NULL, null=True)
    country=models.CharField(max_length=20)
    city=models.CharField(max_length=20)
    state=models.CharField(max_length=20)
    zipcode=models.CharField(max_length=200, null=False, default=0)
    address=models.CharField(max_length=100)

    def __str__(self):
        return self.address




class Order_item(models.Model):
    Order=models.ForeignKey(Order, on_delete=models.SET_NULL, blank=True, null=True)
    Product=models.ForeignKey(Product, on_delete=models.CASCADE, blank=True, null=True)
    quantity=models.IntegerField(default=0, null=True, blank=True)
    # price=models.DecimalField(max_digits=19, decimal_places=10)

    @property
    def get_total(self):
        total = self.Product.price * self.quantity
        return total



# class Shipment(models.Model):
#     Order=models.ForeignKey(Order, on_delete=models.CASCADE)
#     address=models.CharField(max_length=20)
#     address_a=models.ForeignKey(shipping_address, on_delete=models.CASCADE, default=1)
#     tracking_no=models.CharField(max_length=20)
    



